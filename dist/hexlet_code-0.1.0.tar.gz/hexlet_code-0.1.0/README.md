### Hexlet tests and linter status:
[![Actions Status](https://github.com/Mandasik/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Mandasik/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/350d11c4fa9e6c7c5597/maintainability)](https://codeclimate.com/github/Mandasik/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/554721.svg)](https://asciinema.org/a/554721)
[![asciicast](https://asciinema.org/a/555057.svg)](https://asciinema.org/a/555057)
[![asciicast](https://asciinema.org/a/555176.svg)](https://asciinema.org/a/555176)
[![asciicast](https://asciinema.org/a/IVU2soF1TtveS7NFogIg1H6Vm.svg)](https://asciinema.org/a/IVU2soF1TtveS7NFogIg1H6Vm)