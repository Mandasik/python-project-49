### Hexlet tests and linter status:
[![Actions Status](https://github.com/Mandasik/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Mandasik/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/350d11c4fa9e6c7c5597/maintainability)](https://codeclimate.com/github/Mandasik/python-project-49/maintainability)
https://asciinema.org/a/L1F8ZOVEDvbmNtjZnJSioZQt4
https://asciinema.org/a/N4fbVNurqYDX96NYhYkvPb9ap
https://asciinema.org/a/NaozZSwDNq5H64TBwdp4dI0lq